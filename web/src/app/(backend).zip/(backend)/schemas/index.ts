export * from './auth.schema';
export * from './base.schema';
export * from './materia.schema'
