import { getServerSession } from "next-auth";

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);

  if (!session) {
    return new Response("Unauthorized", { status: 401 });
  }

  const name = session.user?.name;

  return Response.json({ message: `Usuário logado: ${name}` });
}
